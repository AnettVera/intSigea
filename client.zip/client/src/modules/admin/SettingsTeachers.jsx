import React from 'react'

const SettingsTeachers = () => {
  return (
    <div>
      Tabla de docentes
    </div>
  )
}

export default SettingsTeachers
